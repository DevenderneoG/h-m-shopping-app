const ProductsList = () => {
  return (
    <div className="container-fluid py-5">
      <div className="row">
        <div className="col-lg-2">
          <label for="customPriceRange" class="form-label">
            Price
          </label>
          <input
            type="range"
            class="form-range"
            min="0"
            max="2000"
            step="1000"
            id="customPriceRange"
            list="priceTickmarks"
          />

          <datalist id="priceTickmarks">
            <option value="0" label="0"></option>
            <option value="1000" label="1000"></option>
            <option value="2000" label="2000"></option>
          </datalist>
        </div>
        <div className="col-lg-8"></div>
      </div>
    </div>
  );
};

export default ProductsList;    
